<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Models\AccessCode;
use App\Models\VehicleManagement;
use Carbon\Carbon;

class RegistrationController extends Controller
{
    /**
     * User Login (Passport Authentication)
     */
    public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'username' => 'required|string',
            'password' => 'required|string|min:6',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation error',
                'errors' => $validator->errors(),
            ], 422);
        }

        // Find user by email or username
        $user = User::where('email', $request->username)
                    ->orWhere('username', $request->username)
                    ->first();

        if (!$user || !Auth::attempt(['email' => $user->email, 'password' => $request->password])) {
            return response()->json([
                'success' => false,
                'message' => 'Invalid credentials',
            ], 401);
        }

        // Generate Passport access token
        $tokenResult = $user->createToken('Personal Access Token');
        $token = $tokenResult->accessToken;

        return response()->json([
            'success' => true,
            'message' => 'Login successful',
            'user' => $user,
            'access_token' => $token,
            'token_type' => 'Bearer',
        ]);
    }

    /**
     * Register a Vehicle Permit
     */
    public function registerPermit(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'lot_code' => 'required|string',
            'license_plate' => 'required|string|max:10',
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 422);
        }

        // Find Lot Number ID using Lot Code or Access Code
        $lot = LotNumber::where('lot_code', $request->lot_code)->first();

        if (!$lot) {
            // If lot code not found in lot_numbers, check access_codes
            $accessCode = AccessCode::where('access_code', $request->lot_code)->first();

            if (!$accessCode) {
                return response()->json([
                    'success' => false,
                    'message' => 'Invalid lot code or access code'
                ], 404);
            }

            // Assign lot based on access code
            $lot = LotNumber::find($accessCode->lot_number_id);
        }

        // Validate lot status (if needed)
        if ($lot->status === 'FreePaid') {
            return response()->json([
                'success' => false,
                'message' => 'This lot requires payment. Please contact management.'
            ], 403);
        }

        // Prevent permit overlap for the same plate
        $existingPermit = VehicleManagement::where('license_plate', $request->license_plate)
            ->where('lot_number_id', $lot->id)
            ->where('end_date', '>=', now())
            ->first();

        if ($existingPermit) {
            return response()->json([
                'success' => false,
                'message' => 'This vehicle already has an active permit.'
            ], 409);
        }

        // Get default duration from lot or assign 1-day permit
        $defaultDuration = $lot->duration ?? '1 Day';

        // Calculate end date
        $startDate = now();
        switch ($defaultDuration) {
            case '1 Day':  $endDate = $startDate->addDay(); break;
            case '7 Days': $endDate = $startDate->addDays(7); break;
            case '1 Month': $endDate = $startDate->addMonth(); break;
            case '1 Year': $endDate = $startDate->addYear(); break;
            case '5 Years': $endDate = $startDate->addYears(5); break;
            default: $endDate = $startDate->addDay(); break;
        }

        // Create vehicle permit
        $permit = new VehicleManagement();
        $permit->lot_number_id = $lot->id;
        $permit->license_plate = strtoupper($request->license_plate);
        $permit->start_date = $startDate;
        $permit->end_date = $endDate;
        $permit->duration_type = $defaultDuration;
        $permit->is_active = 1;
        $permit->status = 'Visitor';
        $permit->save();

        return response()->json([
            'success' => true,
            'message' => 'Vehicle permit registered successfully!',
            'permit' => $permit
        ]);
    }


    /**
     * Get Vehicle Permit History
     */
    public function vehicleHistory(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'lot_code' => 'required|string|exists:lot_numbers,lot_code',
            'license_plate' => 'required|string|max:10',
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 422);
        }

        $history = VehicleManagement::where('license_plate', $request->license_plate)
            ->whereHas('lotNumber', function ($query) use ($request) {
                $query->where('lot_code', $request->lot_code);
            })
            ->orderBy('start_date', 'desc')
            ->limit(30)
            ->get();

        return response()->json([
            'success' => true,
            'history' => $history
        ]);
    }
}
