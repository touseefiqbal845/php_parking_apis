<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Property;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password;

class UserController extends Controller
{
    public function index(Request $request)
    {
        $query = User::with('properties') // Eager load the properties relationship
        ->when($request->search, fn($q) => $q->where('username', 'like', "%{$request->search}%"))
        ->orderBy('username');

        $perPage = $request->per_page === 'all' ? $query->count() : ($request->per_page ?? 10);

        // Paginate the results
        $paginatedUsers = $query->paginate($perPage);

        // Transform the users to include properties as an array of codes/names
        $transformedUsers = $paginatedUsers->getCollection()->map(function ($user) {
            return [
                'id' => $user->id,
                'username' => $user->username,
                'role' => $user->role,
                'note' => $user->note,
                'properties' => $user->properties->pluck('code')->toArray(), // Extract property codes
            ];
        });

        // Replace the collection with the transformed data
        $paginatedUsers->setCollection($transformedUsers);

        return response()->json($paginatedUsers);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'username' => 'required|unique:users|max:255',
            'password' => ['required', Password::defaults()],
            'role' => 'required|in:Admin,Property Manager',
            'note' => 'nullable|string',
            'properties' => 'nullable|array'
        ]);

        $data['password'] = Hash::make($data['password']);
        $data['name'] = $data['username'];
        $user = User::create($data);
        // Process the properties array
            if ($request->has('properties')) {
                $propertyIds = [];

                foreach ($request->properties as $propertyCode) {
                    // Use firstOrCreate to find or create the property by its code
                    $property = Property::firstOrCreate(
                        ['code' => $propertyCode], // Find by the unique property code
                        ['name' => $propertyCode] // Default name if creating a new property
                    );

                    // Collect the property IDs
                    $propertyIds[] = $property->id;
                }

                // Sync the properties with the user
                $user->properties()->sync($propertyIds);
            }

        return response()->json($user->load('properties'), 201);
    }

    public function update(Request $request, User $user)
    {
        $data = $request->validate([
            'username' => 'required|max:255|unique:users,username,'.$user->id,
            'password' => ['nullable', Password::defaults()],
            'role' => 'required|in:Admin,Property Manager',
            'note' => 'nullable|string',
            'properties' => 'nullable|array'
        ]);

        if ($request->filled('password')) {
            $data['password'] = Hash::make($data['password']);
        } else {
            unset($data['password']);
        }

        $user->update($data);
        // Process the properties array
            if ($request->has('properties')) {
                $propertyIds = [];

                foreach ($request->properties as $propertyCode) {
                    // Use firstOrCreate to find or create the property by its code
                    $property = Property::firstOrCreate(
                        ['code' => $propertyCode], // Find by the unique property code
                        ['name' => $propertyCode] // Default name if creating a new property
                    );

                    // Collect the property IDs
                    $propertyIds[] = $property->id;
                }

                // Sync the properties with the user
                $user->properties()->sync($propertyIds);
            }

        return response()->json($user->load('properties'));
    }

    public function destroy(User $user)
    {
        $user->delete();
        return response()->noContent();
    }

    public function bulkDelete(Request $request)
    {
        $request->validate(['ids' => 'required|array']);
        User::whereIn('id', $request->ids)->delete();
        return response()->noContent();
    }

}
