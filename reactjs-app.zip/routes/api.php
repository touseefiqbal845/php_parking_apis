<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\UserController;
use App\Http\Controllers\API\LotNumberController;
use App\Http\Controllers\Api\AccessCodeController;
use App\Http\Controllers\Api\VehicleManagementController;
use App\Http\Controllers\Api\LoginController;

// Route::get('/user', function (Request $request) {
//     return $request->user();
// })->middleware('auth:sanctum');

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::post('/login', [LoginController::class, 'login']);
Route::prefix('users')->group(function () {
    Route::get('/', [UserController::class, 'index']);
    Route::post('/', [UserController::class, 'store']);
    Route::put('/{user}', [UserController::class, 'update']);
    Route::delete('/{user}', [UserController::class, 'destroy']);
    Route::delete('/', [UserController::class, 'bulkDelete']);
});

Route::prefix('lots')->group(function () {
    Route::get('/', [LotNumberController::class, 'index']);
    Route::post('/', [LotNumberController::class, 'store']);
    Route::get('/{lotNumber}', [LotNumberController::class, 'show']);
    Route::put('/{lotNumber}', [LotNumberController::class, 'update']);
    Route::delete('/{id}', [LotNumberController::class, 'destroy']);
    Route::post('/export', [LotNumberController::class, 'export']);
});

Route::prefix('access-codes')->group(function () {
    Route::get('/', [AccessCodeController::class, 'index']);
    Route::post('/bulk', [AccessCodeController::class, 'bulkStore']);
    Route::get('/{accessCode}', [AccessCodeController::class, 'show']);
    Route::put('/{accessCode}', [AccessCodeController::class, 'update']);
    Route::delete('/{id}', [AccessCodeController::class, 'destroy']);
    Route::put('/toggle-active', [AccessCodeController::class, 'toggleActive']);
});

Route::prefix('vehicles')->group(function () {
    Route::get('/', [VehicleManagementController::class, 'index']);
    Route::post('/bulk', [VehicleManagementController::class, 'bulkStore']);
    Route::get('/{vehicle}', [VehicleManagementController::class, 'show']);
    Route::put('/{vehicle}', [VehicleManagementController::class, 'update']);
    Route::delete('/{id}', [VehicleManagementController::class, 'destroy']);
});
