<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Property;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password;

class UserController extends Controller
{
    public function index(Request $request)
    {
        $query = User::with('properties')
            ->when($request->search, fn($q) => $q->where('username', 'like', "%{$request->search}%"))
            ->orderBy('username');

        $perPage = $request->per_page === 'all' ? $query->count() : $request->per_page ?? 10;
        return response()->json($query->paginate($perPage));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'username' => 'required|unique:users|max:255',
            'password' => ['required', Password::defaults()],
            'role' => 'required|in:Admin,Property Manager',
            'note' => 'nullable|string',
            'properties' => 'array'
        ]);

        $data['password'] = Hash::make($data['password']);
        $user = User::create($data);
        $user->properties()->sync($request->properties);

        return response()->json($user->load('properties'), 201);
    }

    public function update(Request $request, User $user)
    {
        $data = $request->validate([
            'username' => 'required|max:255|unique:users,username,'.$user->id,
            'password' => ['nullable', Password::defaults()],
            'role' => 'required|in:Admin,Property Manager',
            'note' => 'nullable|string',
            'properties' => 'array'
        ]);

        if ($request->filled('password')) {
            $data['password'] = Hash::make($data['password']);
        } else {
            unset($data['password']);
        }

        $user->update($data);
        $user->properties()->sync($request->properties);

        return response()->json($user->load('properties'));
    }

    public function destroy(User $user)
    {
        $user->delete();
        return response()->noContent();
    }

    public function bulkDelete(Request $request)
    {
        $request->validate(['ids' => 'required|array']);
        User::whereIn('id', $request->ids)->delete();
        return response()->noContent();
    }

}
